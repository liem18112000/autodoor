

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <h1>All Requests Lists</h1>
    <hr/>
    <div class='row'>
        <div class='col-lg-4 col-md-4 col-sm-6'>
            <a class="btn btn-success btn-block" href="<?php echo e(route('admin.request.new')); ?>" role="button">New Requests</a>
        </div>
        <div class='col-lg-4 col-md-4 col-sm-6'>
            <a class="btn btn-dark btn-block" href="<?php echo e(route('admin.request.old')); ?>" role="button">Old Requests</a>
        </div>
        <div class='col-lg-4 col-md-4 col-sm-12'>
            <a class="btn btn-primary btn-block" href="<?php echo e(route('admin.request.index')); ?>" role="button">All Requests</a>
        </div>
    </div>
    <hr/>
    <table class='display' id='tableID'>
        <thead class='thead-dark'>
            <tr align="center">
                <th>ID</th>
                <th>Sender Name</th>
                <th>Sender Email</th>
                <th>Request Type</th>
                <th>Verified</th>
                <th>Admin</th>
                <th>Created on</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr align="center">
                <td><?php echo e($request->id); ?></td>
                <td><?php echo e($request->user->name); ?></td>
                <td><?php echo e($request->user->email); ?></td>
                <td><?php echo e($request->request_type); ?></td>
                <?php if($request->verified == '1'): ?>
                    <td><b style='color:green'>Verified</b></td>
                <?php else: ?>
                    <td><b style='color:red'>Not verified</b></td>
                <?php endif; ?>
                <?php if($request->authority): ?>
                    <td><b><?php echo e($request->authority); ?></b></td>
                <?php else: ?>
                    <td><b>N/A</b></td>
                <?php endif; ?>
                <td><?php echo e($request->created_at); ?></td>

                <?php if(!$request->authority): ?>
                <td>
                    <a class="btn btn-success mr-2" href="<?php echo e(route('admin.request.accept', $request)); ?>" role="button">Accept</a>
                    
                    <a class="btn btn-danger" href="<?php echo e(route('admin.request.reject', $request)); ?>" role="button">Reject</a>
                </td>
                <?php endif; ?>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#tableID').DataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/request/index.blade.php ENDPATH**/ ?>