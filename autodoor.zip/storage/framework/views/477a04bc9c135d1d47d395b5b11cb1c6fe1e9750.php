

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <form action='<?php echo e(route('employees.update', $employee)); ?>' method="Post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="id">Code</label>
            <input type="text" name="id" id="id" class="form-control" value='<?php echo e($employee->id); ?>' required='required'>
        </div>

        <div class="form-group">
            <label for="fullname">Fullname</label>
            <input type="text" name="fullname" id="fullname" class="form-control" value='<?php echo e($employee->fullname); ?>' required='required'>
        </div>
        <div class="form-group">
            <label for="class">Class</label>
            <input type="text" name="classcode" id="class" class="form-control" value='<?php echo e($employee->classcode); ?>' required='required'>
        </div>

        <button type="submit" class="btn btn-primary btn-lg">Update</button>

    </form>
   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/employee/edit.blade.php ENDPATH**/ ?>