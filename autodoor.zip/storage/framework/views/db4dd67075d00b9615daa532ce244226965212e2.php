

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="card">
            <div class="card-header">Update UID</div>

            <div class="card-body">
                <?php if(auth()->guard()->guest()): ?>
                    You have to login first!!!
                <?php else: ?>
                    <?php if(session('errors')): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <?php echo e(session('success')); ?>

                    <?php endif; ?>
                    
                    <form action="" method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        
                        <label>Code: <?php echo e($Employee->maso); ?>, <?php echo e($Employee->fullname); ?></label>
                        <br>
                        <label>new UID</label>
                        <input type="text" name="uid" id="uid"><br>
                        <button type="submit">Update UID</button>
                        
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/UID/sua.blade.php ENDPATH**/ ?>