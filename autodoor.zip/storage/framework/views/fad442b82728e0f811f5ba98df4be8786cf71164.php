<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    The number of UIDs of AUT and Keuka program: 
                    <br> Total number of registers:<b> <?php echo e($Total['record']); ?></b>
                    
                    <br> - AUT: <?php echo e($Total['AUT']); ?>

                    <br> - Keuka: <?php echo e($Total['Keuka']); ?>

                    <br> - ITEC and visitors: <?php echo e($Total['ITEC']); ?>

                    <hr>
                    <b> Total number of visits (today): <?php echo e($Total['visit']); ?></b> 
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/home.blade.php ENDPATH**/ ?>