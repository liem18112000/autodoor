

<?php $__env->startSection('content'); ?>
<div class="container">
    <table class='display' id='tableID'>
        <thead class='thead-dark'>
            <tr align="center">
                <th>ID</th>
                <th>Fullname</th>
                <th>Email</th>
                <th>Status</th>
                <th>Role</th>
                <th>Created on</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr align="center">
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
                <?php if($user->status == '1'): ?>
                    <td><b style='color:green'>Active</b></td>
                <?php else: ?>
                    <td><b style='color:red'>Disabled</b></td>
                <?php endif; ?>
                <?php if($user->roles->first()->role_type == 1): ?>
                    <td><b>Admin</b></td>
                <?php else: ?>
                    <td><b>Contributor</b></td>
                <?php endif; ?>
                <td><?php echo e($user->created_at); ?></td>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#tableID').DataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/user/index.blade.php ENDPATH**/ ?>