<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\autodoor\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>