

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-body">
            <?php if(auth()->guard()->guest()): ?>
                You have to login first!!!
            <?php else: ?>
                <?php if(session('errors')): ?>
                    <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <?php echo e(session('success')); ?>

                <?php endif; ?>
                <table class='display' id='tableID'>
                    <thead class='thead-dark'>
                        <tr align="center">
                            <th>Code</th>
                            <th>UID</th>
                            <th>Fullname</th>
                            <th>Class</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr align="center">
                            <td><?php echo e($em->id); ?></td>
                            
                            <?php if($Cards->where('employee_id', $em->id)->count() == 0): ?>
                                <td><b style='color:red'>No card found</b></td>
                                <td align="left"><?php echo e($em->fullname); ?></td>
                                <td><?php echo e($em->classcode); ?></td>
                                <td class="center"><i class="fa fa-pencil fa-fw"></i>
                                <a class='btn btn-dark' href='<?php echo e(route('cards.create', $em->id)); ?>'>Assign UID</a>
                            <?php else: ?>
                                <td><b style='color:green'><?php echo e($Cards->where('employee_id', $em->id)->first()->id); ?></b></td>
                                <td align="left"><?php echo e($em->fullname); ?></td>
                                <td><?php echo e($em->classcode); ?></td>
                                <td class="center"><i class="fa fa-pencil fa-fw"></i>
                                <a class='btn btn-primary' href='<?php echo e(route('cards.edit', [$em->id,$Cards->where('employee_id', $em->id)->first()])); ?>'>Update UID</a>
                            <?php endif; ?>
                            
                            <a class="btn btn-success" href="<?php echo e(route('employees.edit', $em)); ?>">Update</a>
                            </td>
                            
                            
                            <td class="center"><i class="fa fa-trash-o fa-fw"></i>
                            <form action="<?php echo e(route('employees.destroy', $em)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type='submit' class='btn btn-danger'>Delete</button></td>
                            </form>
                            
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
<script>
    $('#tableID').DataTable();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/employee/index.blade.php ENDPATH**/ ?>