

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">List of registers</div>

                <div class="card-body">
                    <?php if(auth()->guard()->guest()): ?>
                        You have to login first!!!
                    <?php else: ?>
                        <?php if(session('errors')): ?>
                            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <?php echo e(session('success')); ?>

                        <?php endif; ?>
                        <table>
                            <thead>
                                <tr align="center">
                                    <th>Code</th>
                                    <th>UID</th>
                                    <th>Fullname</th>
                                    <th>Class</th>
                                    <th>Delete</th>
                                    <th>Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr align="center">
                                    <td><?php echo e($em->maso); ?></td>
                                    <td><?php echo e($em->uid); ?></td>
                                    <td align="left"><?php echo e($em->fullname); ?></td>
                                    <td><?php echo e($em->classcode); ?></td>
                                    <td class="center"><i class="fa fa-trash-o fa-fw"></i>
                                    <a href="UIDmgt/xoa/<?php echo e($em->maso); ?>">Delete</a></td>
                                    <td class="center"><i class="fa fa-pencil fa-fw"></i>
                                    <a href="UIDmgt/sua/<?php echo e($em->maso); ?>">Update UID</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views\UID\danhsach.blade.php ENDPATH**/ ?>