

<?php $__env->startSection('content'); ?>
<div class="container">
    
    <form action='<?php echo e(route('employees.store')); ?>' method="Post">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="id">Code</label>
            <input type="text" name="id" id="id" class="form-control" placeholder="Enter code" required='required'>
        </div>

        <div class="form-group">
            <label for="fullname">Fullname</label>
            <input type="text" name="fullname" id="fullname" class="form-control" placeholder="Enter fullname" required='required'>
        </div>
        <div class="form-group">
            <label for="class">Class</label>
            <input type="text" name="classcode" id="class" class="form-control" placeholder="Enter class Eg: Class Code, GUEST, EMPLOYEE, ..." required='required'>
        </div>

        <button type="submit" class="btn btn-primary btn-lg">Create</button>

    </form>
   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\autodoor\resources\views/employee/create.blade.php ENDPATH**/ ?>