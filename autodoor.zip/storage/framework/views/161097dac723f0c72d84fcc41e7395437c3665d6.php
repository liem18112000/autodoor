<?php $__env->startComponent('mail::message'); ?>
# Register request verification

Hello, <?php echo e($user->name); ?>!

Your account will be verified by admin as soon as possible!

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\autodoor\resources\views/mails/register-request.blade.php ENDPATH**/ ?>