<?php $__env->startComponent('mail::message'); ?>
# Welcome to <?php echo e(config('app.name')); ?> Family

Hello, <?php echo e($user->name); ?>!

<?php if($request->verified == '1'): ?>

Your account has been verified by admin.

So, There are so many service you have join now!

<?php else: ?>

Your account has been rejected by admin.

There are some requirement that your account do not have!

<?php endif; ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\autodoor\resources\views/mails/register-feedback.blade.php ENDPATH**/ ?>